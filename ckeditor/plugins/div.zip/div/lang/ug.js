/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'ug', {
	IdInputLabel: 'ID',
	advisoryTitleInputLabel: 'ماۋزۇ',
	cssClassInputLabel: 'ئۇسلۇب تىپىنىڭ ئاتى',
	edit: 'DIV تەھرىر',
	inlineStyleInputLabel: 'قۇر ئىچىدىكى ئۇسلۇبى',
	langDirLTRLabel: 'سولدىن ئوڭغا (LTR)',
	langDirLabel: 'تىل يۆنىلىشى',
	langDirRTLLabel: 'ئوڭدىن سولغا (RTL)',
	languageCodeInputLabel: 'تىل كودى',
	remove: 'DIV چىقىرىۋەت',
	styleSelectLabel: 'ئۇسلۇب',
	title: 'DIV قاچا قۇر',
	toolbar: 'DIV قاچا قۇر'
} );
