/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'hu', {
	IdInputLabel: 'Azonosító',
	advisoryTitleInputLabel: 'Tipp szöveg',
	cssClassInputLabel: 'Stíluslap osztály',
	edit: 'DIV szerkesztése',
	inlineStyleInputLabel: 'Inline stílus',
	langDirLTRLabel: 'Balról jobbra (LTR)',
	langDirLabel: 'Nyelvi irány',
	langDirRTLLabel: 'Jobbról balra (RTL)',
	languageCodeInputLabel: ' Nyelv kódja',
	remove: 'DIV eltávolítása',
	styleSelectLabel: 'Stílus',
	title: 'DIV tároló létrehozása',
	toolbar: 'DIV tároló létrehozása'
} );
