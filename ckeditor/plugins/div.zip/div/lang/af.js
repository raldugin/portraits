/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'af', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Aanbevole Titel',
	cssClassInputLabel: 'CSS klasse',
	edit: 'Wysig Div',
	inlineStyleInputLabel: 'Inlyn Styl',
	langDirLTRLabel: 'Links na regs (LTR)',
	langDirLabel: 'Skryfrigting',
	langDirRTLLabel: 'Regs na links (RTL)',
	languageCodeInputLabel: ' Taalkode',
	remove: 'Verwyder Div',
	styleSelectLabel: 'Styl',
	title: 'Skep Div houer',
	toolbar: 'Skep Div houer'
} );
