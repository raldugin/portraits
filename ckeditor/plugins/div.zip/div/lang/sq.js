/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'sq', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Titull',
	cssClassInputLabel: 'Klasa stili CSS',
	edit: 'Redakto Div',
	inlineStyleInputLabel: 'Stili i brendshëm',
	langDirLTRLabel: 'Nga e majta në të djathë (LTR)',
	langDirLabel: 'Drejtim teksti',
	langDirRTLLabel: 'Nga e djathta në të majtë (RTL)',
	languageCodeInputLabel: 'Kodi i Gjuhës',
	remove: 'Largo Div',
	styleSelectLabel: 'Stil',
	title: 'Krijo Div Përmbajtës',
	toolbar: 'Krijo Div Përmbajtës'
} );
