/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'bg', {
	IdInputLabel: 'ID',
	advisoryTitleInputLabel: 'Препоръчително заглавие',
	cssClassInputLabel: 'Класове за CSS',
	edit: 'Промяна на Div',
	inlineStyleInputLabel: 'В редица',
	langDirLTRLabel: 'Ляво на Дясно (ЛнД)',
	langDirLabel: 'Посока на езика',
	langDirRTLLabel: 'Дясно на Ляво (ДнЛ)',
	languageCodeInputLabel: ' Код на езика',
	remove: 'Премахване на Div',
	styleSelectLabel: 'Стил',
	title: 'Създай Div блок',
	toolbar: 'Създаване на Div контейнер'
} );
