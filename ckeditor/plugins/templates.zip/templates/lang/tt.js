/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'tt', {
	button: 'Шаблоннар',
	emptyListMsg: '(Шаблоннар билгеләнмәгән)',
	insertOption: 'Әлеге эчтәлекне алмаштыру',
	options: 'Шаблон үзлекләре',
	selectPromptMsg: 'Please select the template to open in the editor', // MISSING
	title: 'Эчтәлек шаблоннары'
} );
