/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'sv', {
	button: 'Sidmallar',
	emptyListMsg: '(Ingen mall är vald)',
	insertOption: 'Ersätt aktuellt innehåll',
	options: 'Inställningar för mall',
	selectPromptMsg: 'Var god välj en mall att använda med editorn<br>(allt nuvarande innehåll raderas):',
	title: 'Sidmallar'
} );
